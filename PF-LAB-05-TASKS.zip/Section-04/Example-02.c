#include <stdio.h>

int main()
{
	int a = 5; // binary: 0101 
	
	int result = a << 1; // Left shift operation
	
	printf("Result after left shift: %d\n", result); // Outputs 10, binary: 1010
	
	return 0;
}
